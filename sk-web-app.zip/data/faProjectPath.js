module.exports  = [
    {
        "student": {
            "_id": "auth_users/5874684",
            "_key": "5874684",
            "first": "Mark",
            "last": "B"
        },
        "projects": [
            {
                "name": "Project 1",
                "sequence": 1,
                "fa": [
                    {
                        "_key": "1337033",
                        "_id": "focusAreas/1337033",
                        "_rev": "_VIeil6K--h",
                        "projectSequence": 1,
                        "courseSequence": 1,
                        "course": "English 6",
                        "grade": "6",
                        "name": "Imagery",
                        "standardConnections": [
                            "CCSS.ELA-LITERACY.W.6.3.D",
                            "CCSS.ELA-LITERACY.W.6.3.D"
                        ],
                        "subject": "english",
                        "nextFA": "The Pythagorean Theorem",
                        "currentStd": [
                            "CCSS.ELA-LITERACY.W.6.3.D"
                        ],
                        "nextStd": [
                            "CCSS.Math.Content.8.G.B.7",
                            "CCSS.Math.Content.8.G.B.8"
                        ]
                    }
                ]
            }
        ]
    }
]