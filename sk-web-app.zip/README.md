Clone this repository and then install dependencies with the command:
- npm install 

To run app:
- make sure you have mongodb running locally and with correct user/pwd - if not edit relevant file.
- then to run the app type:
node server.js
- navigate to http://localhost:8080 to view app.

