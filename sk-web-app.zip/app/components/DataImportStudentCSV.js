import React, { Component } from 'react';
import {connect } from 'react-redux';
import Paper from 'material-ui/Paper';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import FontIcon from 'material-ui/FontIcon';
import {Grid, Row, Col} from 'react-bootstrap';
import helper from '../helper';
import uuid from 'uuid';
import DataImportStudentTable from './DataImportStudentTable';
import AutoCompleteCSVFAField from './AutoCompleteCSVFAField';
import ReactDOM from "react-dom";

const style = {
    paper : {
        height: '80%',
        width: '100%',
        marginBottom: 20,
        textAlign: 'center',
        display: 'flex',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    button: {
        marginTop: 12,
        marginBottom: 12,
        display: 'block',
    },
};

class DataImportStudentCSV extends Component{
    constructor(props){
        super(props);
        this.handleUploadFile = this.handleUploadFile.bind(this);  
        this.handleSaveFile = this.handleSaveFile.bind(this);  
        // this.state = {file : ""};
    }
    componentWillMount(){
        // reset datasaved value to hide the messages 
        helper.dataUploadStatus("", "", this.props.dispatch);
    }
    handleUploadFile(e){
        // send to server
        helper.submitCSVFile(e, this.props.dispatch);
        // reset datasaved value to hide the messages 
        helper.dataUploadStatus("", "", this.props.dispatch);
        // reset input value so files with same name can be re-input
      
        var node = ReactDOM.findDOMNode(this.inputEntry);
        node.value="";
    }
    handleSaveFile(){
        // save the displayed data to the server
        helper.saveCSVStudentData(this.props.csvdata, this.props.dispatch);
    }
    render(){
        // add a save button and a clear button
        var component = this;
        if (this.props.saveerror){
            var problemFA = this.props.saveerror.map( function (row, rowindex){
               var  faArrItems = row.map(function (val, index){
                   if ((rowindex > 0) && (component.props.saveerror[rowindex-1][index] !== val)){
                        return <div key={index}>{val}</div>
                   } else if (rowindex === 0){
                        return <div key={index}>{val}</div>
                   }
               })
               
    
                     return <div key={rowindex} className="text-center">{faArrItems}</div>
            
      
            }) 

        }
        return( 
            <div>
                <Row>
                    <Col xs={12} md={12}>
                      {this.props.csvdata ? (<Paper className="data-import-paper" style={style.paper} zDepth={3} >
                            <DataImportStudentTable csvdata={this.props.csvdata} />
                        </Paper>) : ""}
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} md={12}>
                        <p className={(this.props.datasaved === true) ? "text-center" : "text-center hidden-class "}><strong>Data Uploaded Successfully!</strong></p>
                        <p className={(this.props.datasaved === false) ? "text-center" : "text-center hidden-class "}><strong>Error! Problem saving data, please try again or contact support if the problem persists.</strong> </p>
                        <div className={(this.props.saveerror) ? "text-center" : "text-center hidden-class "}>
                        <p>The data has been saved with the exception of the entries with following Focus Area names, these do not exist in the database.</p>
                        {problemFA} 
                        <p><strong>Please contact support to fix this issue.</strong></p>
                        </div>
                        <div className={(this.props.uploaderror) ? "text-center" : "text-center hidden-class "}><p><strong>Error Details</strong></p>
                        {this.props.uploaderror} 
                        </div>
                    </Col>
                </Row>
                {this.props.csvdata ? ( <Row>
                    <Col xs={2} md={4} />
                    <Col xs={8} md={4} >
                        <FlatButton
                        label="Save Data"
                        secondary={true}
                        style={style.button}
                        type="submit"
                        containerElement='label'
                        onTouchTap={this.handleSaveFile}
                        />
                    </Col>
                    <Col xs={2} md={4} />
                </Row> ) : "" }
                <Row>
                    <Col xs={2} md={4} />
                    <Col xs={8} md={4} >
                        <RaisedButton
                        label="Upload File"
                        secondary={true}
                        style={style.button}
                        type="submit"
                        containerElement='label' 
                        icon={<FontIcon className="muidocs-icon-navigation-expand-more" />}>
                        <input type="file" style={{ display: 'none' }} ref={el => this.inputEntry = el} onChange={e => this.handleUploadFile(e)}/>
                        </RaisedButton>
                    </Col>
                    <Col xs={2} md={4} />
            </Row>
            </div>
            
        )
    }
}

const mapStateToProps = (store,ownProps) => {
    return {
        csvdata: store.uploadState.csvdata,
        datasaved: store.uploadState.datasaved,
        uploaderror: store.uploadState.uploaderror,
        saveerror: store.uploadState.saveerror,
    }
}

export default connect(mapStateToProps)(DataImportStudentCSV);

